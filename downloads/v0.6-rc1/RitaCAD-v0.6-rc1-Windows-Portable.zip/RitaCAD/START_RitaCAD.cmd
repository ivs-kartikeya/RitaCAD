@echo off
setlocal
set "RITACAD_EXE=%~dp0RitaCAD.exe"
if not exist "%RITACAD_EXE%" set "RITACAD_EXE=%~dp0bin\RitaCAD.exe"
if not exist "%RITACAD_EXE%" (
    echo RitaCAD.exe was not found beside this launcher or in its bin folder.
    echo.
    echo Right-click the complete ZIP, choose Extract All, and open the extracted folder.
    echo Keep the executable and launcher together. Do not run this launcher inside the ZIP.
    echo.
    pause
    exit /b 2
)
"%RITACAD_EXE%" %*
set "RITACAD_EXIT=%ERRORLEVEL%"
if not "%RITACAD_EXIT%"=="0" (
    echo.
    echo RitaCAD stopped with exit code %RITACAD_EXIT%.
    echo It requires 64-bit Windows and Microsoft .NET Framework 4.8.
    echo Diagnostics: "%LOCALAPPDATA%\Ritagyan Systems\RitaCAD\RitaCAD-error.log"
    echo.
    pause
)
exit /b %RITACAD_EXIT%
